#ifndef CAPTURE_H
#define CAPTURE_H

void cameraSetup();
void cameraCleanup();

#endif




